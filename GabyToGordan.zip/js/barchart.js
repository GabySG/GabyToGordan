var chart;
var height = 200;
var width = 300;
//DEFINE YOUR VARIABLES UP HERE

//Gets called when the page is loaded.
function init(){
  chart = d3.select('#vis').append('svg');
  vis = chart.append('g');
  //PUT YOUR INIT CODE BELOW
  vis.exit().remove();
}

//Called when the update button is clicked
function updateClicked(){
  d3.csv('data/unhcr_persons_of_concern.csv',update);
}

//Callback for when data is loaded
function update(rawdata){
//PUT YOUR UPDATE CODE BELOW
var orig=[]; refuorig=[]; 
    
//Remove previous diagram
var s = d3.selectAll("svg");
s.remove();

//    
//if (getSelectedYear="2005"){var ydata = ;}
    
d3.csv('data/unhcr_persons_of_concern.csv')
                .get(function(error,data){
      
// categorize/nest in category & region
    
    var countryRef = d3.nest()
//    .key(function(d){return d.Year;}).sortKeys(d3.ascending)
    .key(function(d){return d.Year;})
    .key(function(d){return d.Origin;})
    .rollup(function(leaves) {return {"value": d3.sum(leaves, function(d){return parseFloat(d.Refugees);})}})
    .entries(data);
    

    console.log(countryRef);
    
    var year = getSelectedYear();
    var index=year%2005;
//    console.log(index);
    
    var Showdata=countryRef[index];
//     console.log(Showdata);
//     console.log(Showdata.values);
//     console.log(Showdata.values[0].key);

    xdata=[];ydata=[];
    for(var p=0; p<Showdata.values.length; p++){
        xdata.push(Showdata.values[p].key);
        ydata.push(Showdata.values[p].value.value);    
    }

//    console.log(xdata);
//    console.log(ydata);
//    console.log(xdata[0]); //Afgis
//    console.log(ydata[0]); //98154
    
//draw diagram

// Set the dimensions and margins of the graph
var margin = {top: 20, right: 20, bottom: 50, left: 70},
    width = 1500 - margin.left - margin.right,
    height = 600 - margin.top - margin.bottom;

    
    var svg = d3.select("#vis").append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom);

    
//set x&y scale
    var x = d3.scaleBand()
            .domain(xdata)
            .range([0,height]);

    
    var y = d3.scaleLinear()
                .domain([0,d3.max(ydata)])
                .range([0,width]);
//    
//    console.log(ydata);
//    console.log(d3.max(ydata));
//    console.log(y(ydata[0]));
    
//Set color
    var colorArray =        ["steelblue","darkorange","mediumseagreen","tomato","steelblue","darkorange","mediumseagreen","tomato","mediumseagreen","tomato"];
    
//Add a rectangle
    var barWidth = height/xdata.length;
//    console.log(barWidth);
    
    svg.selectAll("rect")       
        .data(ydata)
        .enter().append("rect")
        .attr("height",barWidth-10) //!
        .attr("width",function(d,i){return y(ydata[i]);})
        .attr("x",200) // start point
        .attr("y",function(d,i){return barWidth*i;})
        .attr("fill",function(d,i){return colorArray[i];});
    
//Add axis     
    var xAxis = d3.axisLeft(x).scale(x).ticks(10, ",f");
    var yAxis = d3.axisBottom(y); 
    
//Add x Axis
    svg.append("g")
        .attr("transform", "translate("+ 200+",0)")    
        .call(xAxis);

//Add y axis    
    svg.append("g")
        .attr("transform","translate("+200+","+ (height) +")")
        .call(yAxis);
})
//
// Returns the selected option in the X-axis dropdown.
function getSelectedYear(){
    var node=d3.select('#year').node();
    var i =node.selectedIndex;
    return node[i].value;
}
}